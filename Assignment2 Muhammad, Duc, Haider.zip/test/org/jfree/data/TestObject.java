package org.jfree.data;

public class TestObject {

}
